
public class ArrayLatihan2 {
    public static void main(String[] args) {

        int[][] num = {
                { 1, 2, 3 },
                { 4, 5, 6 }
        };

        int[] array = { 10, 20, 30 };

        for (int i = 0; i < 3; i++) {
            num[1][i] = num[1][i] + array[i];
        }

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(num[i][j] + " ");
            }
            System.out.println();
        }
    }
}
