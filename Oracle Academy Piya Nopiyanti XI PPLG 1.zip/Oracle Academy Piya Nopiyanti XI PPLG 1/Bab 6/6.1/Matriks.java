import java.util.Scanner;

public class Matriks {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[][] A = new int[2][2];
        int[][] B = new int[2][2];

        int pilihan;

        do {
            System.out.println("\n1. Masukkan Matriks A");
            System.out.println("2. Masukkan Matriks B");
            System.out.println("3. Tampilkan A + B");
            System.out.println("4. Tampilkan A - B");
            System.out.println("5. Tampilkan A * B");
            System.out.println("6. Keluar");
            System.out.print("Pilih: ");
            pilihan = input.nextInt();

            if (pilihan == 1 || pilihan == 2) {
                int[][] M = (pilihan == 1) ? A : B;

                for (int i = 0; i < 2; i++) {
                    for (int j = 0; j < 2; j++) {
                        System.out.print("Elemen [" + i + "][" + j + "]: ");
                        M[i][j] = input.nextInt();
                    }
                }
            } else if (pilihan >= 3 && pilihan <= 5) {
                for (int i = 0; i < 2; i++) {
                    for (int j = 0; j < 2; j++) {
                        int hasil = 0;

                        if (pilihan == 3) {
                            hasil = A[i][j] + B[i][j];
                        } else if (pilihan == 4) {
                            hasil = A[i][j] - B[i][j];
                        } else {
                            for (int k = 0; k < 2; k++) {
                                hasil += A[i][k] * B[k][j];
                            }
                        }

                        System.out.print(hasil + "\t");
                    }
                    System.out.println();
                }
            }
        } while (pilihan != 6);

        input.close();
    }
}
