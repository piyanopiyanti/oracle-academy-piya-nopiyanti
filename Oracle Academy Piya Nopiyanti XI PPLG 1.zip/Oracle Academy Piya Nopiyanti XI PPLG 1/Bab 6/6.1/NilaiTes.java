import java.util.Scanner;

public class NilaiTes {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] nilai = new int[5];
        int total = 0;

        for (int i = 0; i < 5; i++) {
            System.out.print("Masukkan nilai tes ke-" + (i + 1) + ": ");
            nilai[i] = input.nextInt();
            total += nilai[i];
        }

        double rataRata = total / 5.0;
        System.out.println("Rata-rata nilai: " + rataRata);

        input.close();
    }
}
