
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        Deck deck = new Deck();
        deck.shuffle();

        System.out.print("Jumlah pemain: ");
        int pemain = input.nextInt();

        System.out.print("Jumlah kartu per pemain: ");
        int jumlahKartu = input.nextInt();

        if (pemain <= 0 || jumlahKartu <= 0
                || pemain * jumlahKartu > deck.cardsLeft()) {

            System.out.println("Jumlah pemain atau kartu tidak valid.");

        } else {

            for (int i = 1; i <= pemain; i++) {

                System.out.println("\nPemain " + i + ":");

                for (int j = 0; j < jumlahKartu; j++) {
                    System.out.println(deck.deal());
                }
            }

            System.out.println("\nSisa kartu: " + deck.cardsLeft());
        }

        input.close();
    }
}
