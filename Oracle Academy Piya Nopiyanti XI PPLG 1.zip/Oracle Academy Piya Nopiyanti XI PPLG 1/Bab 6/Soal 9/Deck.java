
import java.util.ArrayList;
import java.util.Collections;

public class Deck {

    private ArrayList<Card> cards = new ArrayList<>();

    public Deck() {
        String[] suits = {
                "Hearts", "Diamonds", "Clubs", "Spades"
        };

        for (String suit : suits) {
            for (int number = 1; number <= 13; number++) {
                cards.add(new Card(number, suit));
            }
        }
    }

    public void shuffle() {
        Collections.shuffle(cards);
    }

    public Card deal() {
        if (cards.isEmpty()) {
            return null;
        }

        return cards.remove(0);
    }

    public int cardsLeft() {
        return cards.size();
    }
}
