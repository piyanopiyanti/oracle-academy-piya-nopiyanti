
public class Card {

    private String suit;
    private int number;

    public Card(int number, String suit) {
        this.number = number;
        this.suit = suit;
    }

    public String toString() {
        String[] names = {
            "", "Ace", "2", "3", "4", "5", "6",
            "7", "8", "9", "10", "Jack", "Queen", "King"
        };

        return names[number] + " of " + suit;
    }
}
