public class TestVehicle {

    public static void main(String[] args) {

        System.out.println("Manufacturer: " + Vehicle.getMake());

        System.out.println("Number of vehicles manufactured: "
                + Vehicle.numVehicles);

        // Object pertama
        Vehicle vehicle1 = new Vehicle("Vision");

        System.out.println(vehicle1.toString());

        // Object kedua
        Vehicle vehicle2 = new Vehicle("Edict");

        System.out.println(vehicle2.toString());

        // Mengubah static variable
        Vehicle.setMake("Jeep");

        // Menampilkan perubahan MAKE
        System.out.println(vehicle1.toString());
        System.out.println(vehicle2.toString());

        // Membuat object Engine
        Vehicle.Engine vehicle3 = new Vehicle.Engine("Fortune");

        // Menampilkan informasi Engine
        System.out.println(
                "Vehicle number " + vehicle3.getChassisNo()
                        + " is a " + vehicle3.getModel()
                        + " model and has an engine capacity of "
                        + Vehicle.Engine.getCapacity() + "cc");

        // Total kendaraan
        System.out.println("Number of vehicles manufactured: "
                + Vehicle.numVehicles);
    }
}
