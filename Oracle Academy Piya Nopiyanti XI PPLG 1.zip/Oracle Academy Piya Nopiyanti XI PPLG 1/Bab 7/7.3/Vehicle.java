public class Vehicle {

    // Static variables
    public static String MAKE = "Augur";
    public static int numVehicles = 0;

    // Instance variables
    private String chassisNo;
    private String model;

    // Constructor Vehicle
    public Vehicle(String model) {
        numVehicles++;
        this.chassisNo = "ch" + numVehicles;
        this.model = model;

        System.out.println("Vehicle manufactured");
    }

    // Getter and Setter MAKE
    public static String getMake() {
        return MAKE;
    }

    public static void setMake(String make) {
        MAKE = make;
    }

    // Getter and Setter chassisNo
    public String getChassisNo() {
        return chassisNo;
    }

    public void setChassisNo(String chassisNo) {
        this.chassisNo = chassisNo;
    }

    // Getter and Setter model
    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    // Static nested class Engine
    public static class Engine extends Vehicle {

        private static final String MAKE = "Predicter";
        private static final int CAPACITY = 1600;

        // Constructor Engine
        public Engine(String model) {
            super(model);
        }

        // Getter Engine MAKE
        public static String getEngineMake() {
            return MAKE;
        }

        // Getter Engine CAPACITY
        public static int getCapacity() {
            return CAPACITY;
        }
    }

    // toString method
    @Override
    public String toString() {
        return "The vehicle is manufactured by: " + MAKE +
                "\nThe model type is " + model +
                "\nThe chassis number is " + chassisNo +
                "\nThe engine make is " + Engine.getEngineMake() +
                "\nThe engine capacity is " + Engine.getCapacity() + "cc";
    }
}
