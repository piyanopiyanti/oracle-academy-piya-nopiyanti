import java.util.Date;

public class Main {
    public static void main(String[] args) {
        Student s = new Student("Budi", "Santoso", "Wijaya",
                new Date(), "2023001", "Ilmu Komputer", "Sarjana", 2023);

        System.out.println("Nama   : " + s.getName());
        System.out.println("NIM    : " + s.getNim());
        System.out.println("Jurusan: " + s.getMajor());
        System.out.println("Gelar  : " + s.getDegree());

        String[] nilai = { "A", "A-", "B+", "B", "C" };
        double ip = s.calculateGpa(nilai);
        System.out.printf("IP     : %.2f%n", ip);

        s.setGpa(3.5);
        System.out.println("IP setelah diubah admin: " + s.getGpa());
    }
}