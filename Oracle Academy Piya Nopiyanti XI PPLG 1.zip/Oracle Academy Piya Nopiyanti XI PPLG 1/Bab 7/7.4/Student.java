import java.util.Date;

public class Student extends Person {
    private String nim;
    private double gpa; // IP
    private String major; // jurusan
    private String degree; // Sarjana, Magister, Doktor
    private int enrollmentYear; // tahun masuk

    public Student(String firstName, String middleName, String lastName,
            Date dateOfBirth, String nim, String major,
            String degree, int enrollmentYear) {
        super(firstName, middleName, lastName, dateOfBirth);
        this.nim = nim;
        this.major = major;
        this.degree = degree;
        this.enrollmentYear = enrollmentYear;
        this.gpa = 0.0;
    }

    public String getMajor() {
        return major;
    }

    public String getDegree() {
        return degree;
    }

    public int getEnrollmentYear() {
        return enrollmentYear;
    }

    public String getNim() {
        return nim;
    }

    public double getGpa() {
        return gpa;
    }

    // Untuk administrator mengubah IP
    public void setGpa(double gpa) {
        if (gpa >= 0.0 && gpa <= 4.0) {
            this.gpa = gpa;
        }
    }

    // Menghitung IP dari array nilai huruf
    public double calculateGpa(String[] grades) {
        if (grades == null || grades.length == 0)
            return 0.0;
        double total = 0;
        for (String g : grades) {
            total += gradeToPoint(g);
        }
        this.gpa = total / grades.length;
        return this.gpa;
    }

    private double gradeToPoint(String grade) {
        switch (grade) {
            case "A":
                return 4.0;
            case "A-":
                return 3.67;
            case "B+":
                return 3.33;
            case "B":
                return 3.0;
            case "B-":
                return 2.67;
            case "C+":
                return 2.33;
            case "C":
                return 2.0;
            case "D":
                return 1.0;
            case "F":
                return 0.0;
            default:
                return 0.0;
        }
    }
}