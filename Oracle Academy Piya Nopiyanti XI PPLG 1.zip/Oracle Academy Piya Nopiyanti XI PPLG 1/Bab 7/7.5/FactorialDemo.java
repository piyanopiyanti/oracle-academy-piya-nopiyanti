public class FactorialDemo {
    public int num = 10;

    public int getFactorial() {
        int factorial = 1;
        for (int i = num; i > 0; i--) {
            factorial *= i;
        }
        return factorial;
    }

    @Override
    public String toString() {
        String result = "Factorial: " + num + "! = ";
        for (int i = 1; i <= num; i++) {
            result += i;
            if (i < num) {
                result += " * ";
            }
        }
        result += " = " + getFactorial();
        return result;
    }

    public static void main(String[] args) {
        FactorialDemo f = new FactorialDemo();
        System.out.println(f);
    }
}