public class Shape {
    private int numSides;
    private boolean regular;

    // Constructor pertama
    public Shape() {
        numSides = 0;
        regular = false;
    }

    // Constructor kedua
    public Shape(int numSides, boolean regular) {
        this.numSides = numSides;
        this.regular = regular;
    }

    // Getter
    public int getNumSides() {
        return numSides;
    }

    public boolean getRegular() {
        return regular;
    }

    // Setter
    public void setNumSides(int numSides) {
        this.numSides = numSides;
    }

    public void setRegular(boolean regular) {
        this.regular = regular;
    }

    // Main method
    public static void main(String[] args) {

        Shape shape1 = new Shape();
        Shape shape2 = new Shape(4, true);

        System.out.println("Shape 1:");
        System.out.println("Jumlah sisi: " + shape1.getNumSides());
        System.out.println("Beraturan: " + shape1.getRegular());

        System.out.println("\nShape 2:");
        System.out.println("Jumlah sisi: " + shape2.getNumSides());
        System.out.println("Beraturan: " + shape2.getRegular());
    }
}