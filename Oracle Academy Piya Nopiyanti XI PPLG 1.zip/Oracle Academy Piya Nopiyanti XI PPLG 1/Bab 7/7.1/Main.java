public class Main {
    public static void main(String[] args) {

        // Menggunakan constructor pertama
        Animal animal1 = new Animal();

        // Menggunakan constructor kedua
        Animal animal2 = new Animal(60, 5, 10);

        System.out.println("Animal #1 memiliki kecepatan "
                + animal1.getSpeed());

        System.out.println("Animal #2 memiliki kecepatan "
                + animal2.getSpeed());
    }
}
