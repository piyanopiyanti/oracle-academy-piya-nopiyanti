public class Card {
    String suit;
    String name;
    int points;

    // Constructor
    public Card(int n1, int n2) {

        // Menentukan jenis kartu
        String[] suits = {
                "Clubs", "Diamonds", "Hearts", "Spades"
        };

        suit = suits[n1 - 1];

        // Menentukan nama kartu
        if (n2 == 1) {
            name = "Ace";
        } else if (n2 == 11) {
            name = "Jack";
        } else if (n2 == 12) {
            name = "Queen";
        } else if (n2 == 13) {
            name = "King";
        } else {
            name = String.valueOf(n2);
        }

        // Menentukan poin kartu
        if (n2 >= 10) {
            points = 10;
        } else {
            points = n2;
        }
    }

    public String toString() {
        return "The " + name + " of " + suit;
    }

    public String getName() {
        return name;
    }

    public int getPoints() {
        return points;
    }

    public String getSuit() {
        return suit;
    }
}
