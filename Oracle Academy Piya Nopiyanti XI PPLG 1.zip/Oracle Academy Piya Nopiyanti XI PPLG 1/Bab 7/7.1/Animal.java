
public class Animal {

    // INSTANCE VARIABLE (BINTANG)
    int weight, height;
    double speed;

    // CONSTRUCTOR PERTAMA (KOTAK)
    Animal() {
        weight = 50;
        height = 4;
        speed = 2;
    }

    // CONSTRUCTOR KEDUA (KOTAK)
    // w, h, s = PARAMETER (SEGITIGA)
    Animal(int w, int h, int s) {
        weight = w;
        height = h;
        speed = s;
    }

    // double = RETURN TYPE (GARIS BAWAH)
    // miles = PARAMETER (SEGITIGA)
    public double getTime(double miles) {
        return miles / speed;
    }

    // int = RETURN TYPE (GARIS BAWAH)
    public int getWeight() {
        return weight;
    }

    // int = RETURN TYPE (GARIS BAWAH)
    public int getHeight() {
        return height;
    }

    // double = RETURN TYPE (GARIS BAWAH)
    public double getSpeed() {
        return speed;
    }

    // MAIN METHOD UNTUK MENJALANKAN PROGRAM
    public static void main(String[] args) {

        Animal animal1 = new Animal();
        Animal animal2 = new Animal(60, 5, 10);

        System.out.println("Animal 1");
        System.out.println("Weight: " + animal1.getWeight());
        System.out.println("Height: " + animal1.getHeight());
        System.out.println("Speed: " + animal1.getSpeed());

        System.out.println("\nAnimal 2");
        System.out.println("Weight: " + animal2.getWeight());
        System.out.println("Height: " + animal2.getHeight());
        System.out.println("Speed: " + animal2.getSpeed());
    }
}
