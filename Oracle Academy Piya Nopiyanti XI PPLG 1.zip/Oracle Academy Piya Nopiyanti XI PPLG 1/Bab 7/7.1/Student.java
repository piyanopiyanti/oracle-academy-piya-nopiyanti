public class Student {
    String name;
    int credit;
    double ip;
    double points;

    // Constructor
    public Student(String name, int credit, double points) {
        this.name = name;
        this.credit = credit;
        this.points = points;
        this.ip = points / credit;
    }

    // Method menghitung IP
    public double getIP() {
        return points / credit;
    }

    // Method menambahkan kredit dan poin mutu
    public void addCourse(int credit, double points) {
        this.credit += credit;
        this.points += points;
        this.ip = this.points / this.credit;
    }

    public static void main(String[] args) {

        Student student1 = new Student("Mary Jones", 14, 46);

        Student student2 = new Student("John Stiner", 60, 173);

        Student student3 = new Student("Ari Samala", 31, 69);

        System.out.println("Nama: " + student1.name);
        System.out.println("IP: " + student1.getIP());

        System.out.println("\nNama: " + student2.name);
        System.out.println("IP: " + student2.getIP());

        System.out.println("\nNama: " + student3.name);
        System.out.println("IP: " + student3.getIP());

        student3.addCourse(13, 52);

        System.out.println("\nSetelah menambahkan kredit:");
        System.out.println("Kredit: " + student3.credit);
        System.out.println("Poin mutu: " + student3.points);
        System.out.println("IP: " + student3.getIP());
    }
}
