
public class Employee {

    private String nama;
    private String alamat;
    private double gaji;
    private String nomorTelepon;

    public Employee(String nama, String alamat, double gaji, String nomorTelepon) {
        this.nama = nama;
        this.alamat = alamat;
        this.gaji = gaji;
        this.nomorTelepon = nomorTelepon;
    }

    public void tampilkanData() {
        System.out.println("Data Employee");
        System.out.println("Nama: " + nama);
        System.out.println("Alamat: " + alamat);
        System.out.println("Gaji: " + gaji);
        System.out.println("Nomor Telepon: " + nomorTelepon);
    }

    public static void main(String[] args) {
        Employee pegawai = new Employee(
                "Piya",
                "Bogor",
                5000000,
                "08123456789");

        pegawai.tampilkanData();
    }
}
