public class Fish {

    // Instance Variable
    String typeOfFish;
    int friendliness;

    // Constructor tanpa parameter
    public Fish() {
        typeOfFish = "Unknown";
        friendliness = 3;
    }

    // Constructor dengan parameter
    public Fish(String t, int f) {
        typeOfFish = t;
        friendliness = f;
    }

    // Method getFriendliness
    public int getFriendliness() {
        return friendliness;
    }

    // Method nicestFish dengan Variable Arguments
    public static Fish nicestFish(Fish... fishes) {
        Fish temp = fishes[0];

        for (Fish fish : fishes) {
            if (fish.getFriendliness() > temp.getFriendliness()) {
                temp = fish;
            }
        }

        return temp;
    }

    // Main Method
    public static void main(String[] args) {

        // Membuat objek ikan
        Fish Amber = new Fish("Angelfish", 5);
        Fish James = new Fish("Guppy", 3);
        Fish Alex = new Fish("Goldfish", 4);

        // Menampilkan data ikan
        System.out.println("Data Ikan:");
        System.out.println(Amber.typeOfFish);
        System.out.println(James.typeOfFish);
        System.out.println(Alex.typeOfFish);

        // Membandingkan keramahan ikan
        Fish result = nicestFish(Amber, James, Alex);

        System.out.println("\nIkan Paling Ramah:");
        System.out.println("Jenis Ikan: " + result.typeOfFish);
        System.out.println("Friendliness: " + result.getFriendliness());
    }
}
