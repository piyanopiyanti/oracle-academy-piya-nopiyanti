
public class BasicMath {

    public int penjumlahan(int a, int b) {
        return a + b;
    }

    public static void main(String[] args) {

        BasicMath math = new BasicMath();

        int hasil = math.penjumlahan(10, 5);

        System.out.println("Hasil Penjumlahan: " + hasil);
    }
}
