public class StudentDriver {
    public static void main(String[] args) {
        // Membuat instance objek baru dari class Student dan memasukkan data mahasiswa
        Student lisa = new Student("Lisa", "Palombo", 123456789, "Active");

        // Mencetak informasi objek Student ke layar sesuai format yang diminta
        System.out.println("Student Name: " + lisa.fName + " " + lisa.lName);
        System.out.println("Student ID: " + lisa.stuId);
        System.out.println("Student Status: " + lisa.stuStatus);
    }
}