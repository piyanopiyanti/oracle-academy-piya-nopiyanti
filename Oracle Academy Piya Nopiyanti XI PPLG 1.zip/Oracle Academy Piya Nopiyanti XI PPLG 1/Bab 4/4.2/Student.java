public class Student {
    // Deklarasi variabel anggota (attributes) sesuai spesifikasi tugas
    public String fName;
    public String lName;
    public int stuId;
    public String stuStatus;

    // Constructor untuk menginisialisasi data objek Student saat pertama kali
    // dibuat
    public Student(String firstName, String lastName, int id, String status) {
        this.fName = firstName;
        this.lName = lastName;
        this.stuId = id;
        this.stuStatus = status;
    }
}