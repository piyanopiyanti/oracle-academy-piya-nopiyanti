
import java.util.Scanner;

public class LuasSegitiga {
    public static void main(String[] args) {

        Scanner in = new Scanner(System.in);

        // Meminta input alas
        System.out.print("Masukkan alas segitiga (b): ");
        double b = in.nextDouble();

        // Meminta input tinggi
        System.out.print("Masukkan tinggi segitiga (h): ");
        double h = in.nextDouble();

        // Menghitung luas segitiga
        double A = 0.5 * b * h;

        // Menampilkan hasil
        System.out.println("Luas Segitiga (A) = " + A);

        in.close();
    }
}
