import java.util.Arrays;
import java.util.Scanner;

public class Anagram {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Masukkan kata pertama: ");
        String kata1 = input.nextLine();

        System.out.print("Masukkan kata kedua: ");
        String kata2 = input.nextLine();

        kata1 = kata1.toLowerCase().replaceAll("[^a-z]", "");
        kata2 = kata2.toLowerCase().replaceAll("[^a-z]", "");

        char[] huruf1 = kata1.toCharArray();
        char[] huruf2 = kata2.toCharArray();

        Arrays.sort(huruf1);
        Arrays.sort(huruf2);

        if (Arrays.equals(huruf1, huruf2)) {
            System.out.println("Kedua kata adalah anagram.");
        } else {
            System.out.println("Kedua kata bukan anagram.");
        }

        input.close();
    }
}
