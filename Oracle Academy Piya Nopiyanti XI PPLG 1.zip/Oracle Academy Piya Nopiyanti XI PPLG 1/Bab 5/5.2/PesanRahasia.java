import java.util.Scanner;

public class PesanRahasia {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        for (int i = 1; i <= 10; i++) {
            System.out.print("Masukkan angka: ");
            int angka = input.nextInt();

            switch (angka) {
                case 1:
                    System.out.print("D");
                    break;
                case 2:
                    System.out.print("W");
                    break;
                case 3:
                    System.out.print("E");
                    break;
                case 4:
                    System.out.print("L");
                    break;
                case 5:
                    System.out.print("H");
                    break;
                case 6:
                    System.out.print("O");
                    break;
                case 7:
                    System.out.print("R");
                    break;
                default:
                    System.out.println("Angka tidak dikenal, ulangi.");
                    i--;
            }
        }

        input.close();
    }
}
