import java.util.Scanner;

public class BeratPlanet {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Masukkan berat badan di Bumi (lbs): ");
        double berat = input.nextDouble();

        System.out.println("Pilih planet:");
        System.out.println("1. Merkurius");
        System.out.println("2. Venus");
        System.out.println("3. Mars");
        System.out.println("4. Jupiter");
        System.out.println("5. Saturnus");
        System.out.println("6. Uranus");
        System.out.println("7. Neptunus");
        System.out.print("Pilihan: ");

        int pilihan = input.nextInt();
        double faktor = 0;

        switch (pilihan) {
            case 1:
                faktor = 0.38;
                break;
            case 2:
                faktor = 0.91;
                break;
            case 3:
                faktor = 0.38;
                break;
            case 4:
                faktor = 2.36;
                break;
            case 5:
                faktor = 0.92;
                break;
            case 6:
                faktor = 0.89;
                break;
            case 7:
                faktor = 1.13;
                break;
            default:
                System.out.println("Pilihan tidak valid.");
                input.close();
                return;
        }

        System.out.println("Berat Anda di planet tersebut: "
                + (berat * faktor) + " lbs");

        input.close();
    }
}
