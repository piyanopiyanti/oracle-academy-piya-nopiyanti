import java.util.Scanner;

public class HitungCat {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Masukkan panjang ruangan (ft): ");
        double panjang = input.nextDouble();

        System.out.print("Masukkan lebar ruangan (ft): ");
        double lebar = input.nextDouble();

        System.out.print("Masukkan tinggi ruangan (ft): ");
        double tinggi = input.nextDouble();

        double luasDinding = 2 * (panjang * tinggi)
                + 2 * (lebar * tinggi);

        double luasPlafon = panjang * lebar;

        double totalLuas = luasDinding + luasPlafon;

        int ember5Liter = (int) (totalLuas / 1500);
        double sisaLuas = totalLuas - (ember5Liter * 1500);

        int ember1Liter = (int) Math.ceil(sisaLuas / 300);

        System.out.println("Total luas: " + totalLuas + " kaki persegi");
        System.out.println("Ember 5 liter: " + ember5Liter);
        System.out.println("Ember 1 liter: " + ember1Liter);

        input.close();
    }
}
