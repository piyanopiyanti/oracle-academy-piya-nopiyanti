import java.util.Scanner;

public class FinalExam {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Masukkan nilai rata-rata: ");
        double average = input.nextDouble();

        System.out.print("Masukkan jumlah absen: ");
        int daysAbsent = input.nextInt();

        boolean exempt = false;

        if (average >= 90) {
            if (daysAbsent <= 3) {
                exempt = true;
            }
        } else if (average >= 80) {
            if (daysAbsent == 0) {
                exempt = true;
            }
        }

        if (exempt) {
            System.out.println("Congratulations! You are exempt from the final exam.");
        } else {
            System.out.println("You are not exempt from the final exam.");
        }

        input.close();
    }
}
