import java.util.Scanner;

public class OperasiBilangan {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Masukkan bilangan pertama: ");
        double a = input.nextDouble();

        System.out.print("Masukkan bilangan kedua: ");
        double b = input.nextDouble();

        System.out.println("Penjumlahan: " + (a + b));
        System.out.println("Pengurangan: " + (a - b));
        System.out.println("Perkalian: " + (a * b));
        System.out.println("Pembagian: " + (a / b));

        input.close();
    }
}
