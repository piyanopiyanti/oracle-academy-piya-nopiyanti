import java.util.Scanner;

public class Penerimaan {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Masukkan nilai GPA: ");
        double gpa = input.nextDouble();

        System.out.print("Masukkan nilai SAT: ");
        int sat = input.nextInt();

        if (gpa >= 4.0 && sat >= 1100) {
            System.out.println("Diterima sebagai mahasiswa atau salutatorian.");
        } else if (gpa >= 3.5 && sat >= 1300) {
            System.out.println("Diterima sebagai mahasiswa.");
        } else if (gpa >= 3.0 && sat >= 1500) {
            System.out.println("Diterima sebagai mahasiswa.");
        } else {
            System.out.println("Tidak memenuhi syarat penerimaan.");
        }

        input.close();
    }
}
